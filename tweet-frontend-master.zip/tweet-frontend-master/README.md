# TWEETER

### App Demo: www.linkegoeshere.com



## Concept:



## Technologies Used:

* HTML
* Tailwind
* JavaScript 
* React
* Ruby/Ruby on Rails


##### Credits:

  Arthur and the whole IA squad

## Approach:

#### Overview


#### Wireframe




#### User stories

 

#### Development Plan 

description of your development plan 

* Development Plan  ONE
* Create wire frame Brainstorm actor and actor actions Brainstorm user stories
* Development Plan  Two
* Psuedo-code functionality
* Development Plan  Three 
* Start creating functionality, incorporate CSS and HTML
* Development Plan  Four
* Deploy and test app and Refactor code

#### MVP



#### Stretch goals



## Challenges:




### App Demo: www.linkegoeshere.com


