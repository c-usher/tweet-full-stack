// import { useEffect, useState } from "react";


// const deleteTweet = useState = async (e) => {

//   useEffect(() => {
//   try {
//     const response = await fetch(
//       "https://tweet-backend-api.herokuapp.com/tweets/${props.match.params.id}",
//       {
//         method: "DELETE",
//         headers: {
//           "Content-type": "application/json",
//         }
//       }
//     );

//     const data = await response.json();
//   } catch (error) {
//     console.error(error);
//   } finally {
//     window.location.assign('/')
//   }
// })
// }

// export default deleteTweet;